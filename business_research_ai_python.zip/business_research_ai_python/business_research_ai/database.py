from __future__ import annotations
import json, sqlite3
from pathlib import Path
from datetime import datetime, timezone

SCHEMA = '''
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS companies(id INTEGER PRIMARY KEY, name TEXT NOT NULL, website TEXT, description TEXT, headquarters TEXT, founded_year TEXT, products TEXT, source_url TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS research_queries(id INTEGER PRIMARY KEY, query TEXT NOT NULL, research_type TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS search_results(id INTEGER PRIMARY KEY, query_id INTEGER, title TEXT, url TEXT, description TEXT, provider TEXT, retrieved_at TEXT, FOREIGN KEY(query_id) REFERENCES research_queries(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS scraped_pages(id INTEGER PRIMARY KEY, url TEXT NOT NULL, title TEXT, description TEXT, headings TEXT, text_content TEXT, retrieved_at TEXT NOT NULL, status TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS competitors(id INTEGER PRIMARY KEY, company_id INTEGER, name TEXT NOT NULL, website TEXT, products TEXT, pricing TEXT, features TEXT, strengths TEXT, weaknesses TEXT, positioning TEXT, source_url TEXT, FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE SET NULL);
CREATE TABLE IF NOT EXISTS competitor_comparisons(id INTEGER PRIMARY KEY, name TEXT NOT NULL, payload TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS market_research(id INTEGER PRIMARY KEY, topic TEXT NOT NULL, findings TEXT NOT NULL, sources TEXT NOT NULL DEFAULT '[]', created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS ai_analyses(id INTEGER PRIMARY KEY, topic TEXT NOT NULL, analysis_type TEXT NOT NULL, content TEXT NOT NULL, sources TEXT NOT NULL DEFAULT '[]', created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS saved_reports(id INTEGER PRIMARY KEY, report_name TEXT NOT NULL, research_type TEXT NOT NULL, subject TEXT NOT NULL, status TEXT NOT NULL, content TEXT NOT NULL, sources TEXT NOT NULL DEFAULT '[]', created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS application_settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS activity_logs(id INTEGER PRIMARY KEY, action TEXT NOT NULL, details TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_queries_created ON research_queries(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reports_created ON saved_reports(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_scraped_url ON scraped_pages(url);
'''

def now_iso(): return datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds')

class Database:
    def __init__(self, path: str | Path | None = None):
        if path is None:
            base = Path.home() / '.business_research_ai'
            base.mkdir(parents=True, exist_ok=True)
            path = base / 'research.sqlite3'
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as con:
            con.executescript(SCHEMA)
            con.execute("INSERT OR IGNORE INTO application_settings(key,value) VALUES('schema_version','1')")

    def connect(self):
        con = sqlite3.connect(self.path, timeout=10)
        con.row_factory = sqlite3.Row
        con.execute('PRAGMA foreign_keys=ON')
        return con

    def log(self, action, details=''):
        with self.connect() as con: con.execute('INSERT INTO activity_logs(action,details,created_at) VALUES(?,?,?)',(action,details,now_iso()))

    def add_query(self, query, kind, status='Completed'):
        with self.connect() as con:
            cur=con.execute('INSERT INTO research_queries(query,research_type,status,created_at) VALUES(?,?,?,?)',(query,kind,status,now_iso()))
            return cur.lastrowid

    def add_scraped_page(self, page):
        with self.connect() as con:
            cur=con.execute('INSERT INTO scraped_pages(url,title,description,headings,text_content,retrieved_at,status) VALUES(?,?,?,?,?,?,?)',
              (page['url'],page.get('title',''),page.get('description',''),json.dumps(page.get('headings',[]),ensure_ascii=False),page.get('text',''),now_iso(),page.get('status','Completed')))
            self.log_in_connection(con,'Webpage scraped',page['url'])
            return cur.lastrowid

    @staticmethod
    def log_in_connection(con, action, details):
        con.execute('INSERT INTO activity_logs(action,details,created_at) VALUES(?,?,?)',(action,details,now_iso()))

    def save_report(self, name, kind, subject, content, sources=None, status='Completed'):
        with self.connect() as con:
            cur=con.execute('INSERT INTO saved_reports(report_name,research_type,subject,status,content,sources,created_at) VALUES(?,?,?,?,?,?,?)',
              (name,kind,subject,status,content,json.dumps(sources or [],ensure_ascii=False),now_iso()))
            self.log_in_connection(con,'Report saved',name)
            return cur.lastrowid

    def rows(self, sql, params=()):
        with self.connect() as con: return [dict(r) for r in con.execute(sql,params).fetchall()]

    def setting(self, key, default=''):
        rows=self.rows('SELECT value FROM application_settings WHERE key=?',(key,))
        return rows[0]['value'] if rows else default

    def set_setting(self, key, value):
        with self.connect() as con: con.execute('INSERT INTO application_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(key,value))
