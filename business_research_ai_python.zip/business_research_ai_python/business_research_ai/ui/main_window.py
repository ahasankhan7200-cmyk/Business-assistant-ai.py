from __future__ import annotations
import json, os
from datetime import datetime
from pathlib import Path
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (QMainWindow,QWidget,QHBoxLayout,QVBoxLayout,QLabel,QPushButton,QStackedWidget,QFrame,QLineEdit,QTextEdit,QTableWidget,QTableWidgetItem,QHeaderView,QMessageBox,QFileDialog,QComboBox,QFormLayout,QSpinBox,QProgressBar,QTabWidget,QSplitter)
from ..database import Database, now_iso
from ..services.scraper import PublicWebScraper
from ..services.search import SearchService
from ..services.analysis import AIService
from ..services.exporter import export_csv, export_json

STYLE='''QMainWindow,QWidget#workspace{background:#f5f7fb;color:#18243a;font-family:Segoe UI,Arial;font-size:13px} QFrame#sidebar{background:#101d35} QLabel#brand{color:white;font-size:19px;font-weight:700} QLabel#muted{color:#718096} QPushButton{padding:9px 12px;border:1px solid #d8dfeb;border-radius:7px;background:white;text-align:left} QPushButton:hover{background:#eaf1ff} QPushButton#primary{background:#3568e8;color:white;border:0;font-weight:600} QPushButton#nav{background:transparent;color:#d5deee;border:0;text-align:left;padding:12px} QPushButton#nav:checked{background:#263b61;color:white} QLineEdit,QTextEdit,QComboBox{background:white;border:1px solid #d8dfeb;border-radius:6px;padding:8px} QTableWidget{background:white;border:1px solid #e1e6ef;gridline-color:#edf0f5} QHeaderView::section{background:#eef2f8;padding:8px;border:0;font-weight:600} QFrame#card{background:white;border:1px solid #e1e6ef;border-radius:10px}'''

class Worker(QThread):
    succeeded=Signal(object); failed=Signal(str)
    def __init__(self, fn): super().__init__(); self.fn=fn
    def run(self):
        try: self.succeeded.emit(self.fn())
        except Exception as e: self.failed.emit(str(e))

class MainWindow(QMainWindow):
    NAV=['Home','Business Research','Competitor Analysis','Web Scraping','AI Analysis','Saved Reports','Settings']
    def __init__(self):
        super().__init__(); self.db=Database(); self.worker=None; self.latest_page=None
        self.setWindowTitle('Business Research AI'); self.resize(1320,820); self.setMinimumSize(980,650); self.setStyleSheet(STYLE)
        root=QWidget(); lay=QHBoxLayout(root); lay.setContentsMargins(0,0,0,0); lay.setSpacing(0)
        side=QFrame(); side.setObjectName('sidebar'); side.setFixedWidth(230); sv=QVBoxLayout(side); sv.setContentsMargins(14,22,14,16)
        brand=QLabel('◈  Business Research AI'); brand.setObjectName('brand'); brand.setWordWrap(True); sv.addWidget(brand)
        sub=QLabel('Market intelligence workspace'); sub.setStyleSheet('color:#9fb0ca;padding:8px 2px 20px'); sv.addWidget(sub)
        self.nav_buttons=[]
        for i,name in enumerate(self.NAV):
            b=QPushButton(('⌂  ' if i==0 else '▦  ')+name); b.setObjectName('nav'); b.setCheckable(True); b.clicked.connect(lambda checked=False,idx=i:self.navigate(idx)); sv.addWidget(b); self.nav_buttons.append(b)
        sv.addStretch(); self.status_label=QLabel('●  System Ready\nPowered by Python & Qt'); self.status_label.setStyleSheet('color:#9fb0ca;padding:8px'); sv.addWidget(self.status_label)
        self.stack=QStackedWidget(); self.stack.setObjectName('workspace'); lay.addWidget(side); lay.addWidget(self.stack,1); self.setCentralWidget(root)
        for builder in (self.home_page,self.research_page,self.competitor_page,self.scrape_page,self.ai_page,self.reports_page,self.settings_page): self.stack.addWidget(builder())
        self.navigate(0)

    def card(self,title,subtitle=''):
        f=QFrame(); f.setObjectName('card'); v=QVBoxLayout(f); v.setContentsMargins(18,16,18,16); h=QLabel(title); h.setStyleSheet('font-size:16px;font-weight:650'); v.addWidget(h)
        if subtitle: s=QLabel(subtitle); s.setObjectName('muted'); s.setWordWrap(True); v.addWidget(s)
        return f,v
    def page(self,title,subtitle=''):
        w=QWidget(); v=QVBoxLayout(w); v.setContentsMargins(28,24,28,24); v.setSpacing(16)
        h=QLabel(title); h.setStyleSheet('font-size:25px;font-weight:700;color:#17243b'); v.addWidget(h)
        if subtitle: s=QLabel(subtitle); s.setObjectName('muted'); s.setWordWrap(True); v.addWidget(s)
        return w,v
    def button(self,label,callback,primary=False):
        b=QPushButton(label); b.clicked.connect(callback)
        if primary: b.setObjectName('primary')
        return b
    def navigate(self,index):
        self.stack.setCurrentIndex(index)
        for i,b in enumerate(self.nav_buttons): b.setChecked(i==index)
        if index==0: self.refresh_home()
        if index==5: self.refresh_reports()
    def home_page(self):
        w,v=self.page('Welcome back','Research companies, understand competitors, and turn public evidence into actionable insights.')
        cards=QHBoxLayout()
        for title,desc,idx in [('Business Research','Research a company or product',1),('Competitor Analysis','Compare market alternatives',2),('Market Analysis','Explore trends and opportunities',4),('Web Scraping','Extract permitted public pages',3)]:
            f,fl=self.card(title,desc); fl.addWidget(self.button('Open →',lambda checked=False,i=idx:self.navigate(i),True)); cards.addWidget(f)
        v.addLayout(cards); f,fl=self.card('Recent Activity','Actual activity stored in your local SQLite database'); v.addWidget(f)
        self.activity_table=QTableWidget(0,4); self.activity_table.setHorizontalHeaderLabels(['Activity','Details','Timestamp','Status']); self.activity_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch); fl.addWidget(self.activity_table)
        return w
    def refresh_home(self):
        if not hasattr(self,'activity_table'): return
        rows=self.db.rows('SELECT action,details,created_at FROM activity_logs ORDER BY id DESC LIMIT 12'); self.activity_table.setRowCount(len(rows))
        for r,row in enumerate(rows):
            for c,val in enumerate([row['action'],row['details'],row['created_at'],'Recorded']): self.activity_table.setItem(r,c,QTableWidgetItem(str(val)))
    def research_page(self):
        w,v=self.page('Business Research','Search public web results using a configured search provider. Results depend on provider coverage.')
        row=QHBoxLayout(); self.research_input=QLineEdit(); self.research_input.setPlaceholderText('Company, product, industry, or market'); row.addWidget(self.research_input,1); row.addWidget(self.button('Search',self.do_search,True)); v.addLayout(row)
        self.search_table=QTableWidget(0,3); self.search_table.setHorizontalHeaderLabels(['Title','URL','Description']); self.search_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch); self.search_table.setWordWrap(True); v.addWidget(self.search_table,1)
        row=QHBoxLayout(); row.addWidget(self.button('Save results as report',self.save_search_report)); row.addWidget(self.button('Open selected URL',self.open_selected)); v.addLayout(row)
        self.search_results=[]; return w
    def do_search(self):
        q=self.research_input.text().strip()
        if not q: return self.error('Enter a company, product, industry, or market.')
        key=self.db.setting('search_api_key')
        self.start_worker(lambda: SearchService(key).search(q,int(self.db.setting('results_per_page','10'))),self.search_done)
    def search_done(self,results):
        self.search_results=results; self.db.add_query(self.research_input.text().strip(),'Business Research','Completed'); self.db.log('Search completed',f'{len(results)} results for {self.research_input.text().strip()}')
        self.search_table.setRowCount(len(results))
        for i,x in enumerate(results):
            for c,k in enumerate(('title','url','description')): self.search_table.setItem(i,c,QTableWidgetItem(x.get(k,'')))
        self.refresh_home()
        if not results: QMessageBox.information(self,'No results','The search provider returned no results.')
    def open_selected(self):
        row=self.search_table.currentRow()
        if row<0 or row>=len(self.search_results): return self.error('Select a search result first.')
        import webbrowser; webbrowser.open(self.search_results[row]['url'])
    def save_search_report(self):
        if not getattr(self,'search_results',[]): return self.error('There are no search results to save.')
        content='\n\n'.join(f"{x['title']}\n{x['url']}\n{x['description']}" for x in self.search_results)
        self.db.save_report('Business research: '+self.research_input.text(),'Business Research',self.research_input.text(),content,[x['url'] for x in self.search_results]); self.notice('Report saved.'); self.refresh_home()
    def competitor_page(self):
        w,v=self.page('Competitor Analysis','Search a target market, then review sourced candidates. Comparative strengths and weaknesses require evidence.')
        row=QHBoxLayout(); self.comp_input=QLineEdit(); self.comp_input.setPlaceholderText('Company or industry'); row.addWidget(self.comp_input,1); row.addWidget(self.button('Find competitors',self.do_competitor_search,True)); v.addLayout(row)
        self.comp_text=QTextEdit(); self.comp_text.setPlaceholderText('Search results and source links will appear here. No rankings or claims are fabricated.'); v.addWidget(self.comp_text,1)
        v.addWidget(self.button('Save comparison report',lambda:self.db.save_report('Competitor research','Competitor Analysis',self.comp_input.text(),self.comp_text.toPlainText(),[] ) and self.notice('Report saved.'))); return w
    def do_competitor_search(self):
        q=self.comp_input.text().strip()
        if not q:return self.error('Enter a company or industry.')
        self.start_worker(lambda: SearchService(self.db.setting('search_api_key')).search(q+' competitors products pricing',10),lambda rows:self.show_competitors(q,rows))
    def show_competitors(self,q,rows):
        self.comp_text.setPlainText('\n\n'.join(f"{x['title']}\n{x['url']}\n{x['description']}\nEvidence not independently verified beyond this source." for x in rows) or 'No results found.')
        self.db.add_query(q,'Competitor Analysis'); self.db.log('Competitor discovery',q); self.refresh_home()
    def scrape_page(self):
        w,v=self.page('Web Scraping','Retrieve and parse publicly accessible HTML only. Local/private destinations, unsupported content, and oversized responses are blocked.')
        row=QHBoxLayout(); self.url_input=QLineEdit(); self.url_input.setPlaceholderText('https://example.com'); row.addWidget(self.url_input,1); row.addWidget(self.button('Scrape page',self.do_scrape,True)); v.addLayout(row)
        self.scrape_output=QTextEdit(); self.scrape_output.setReadOnly(True); v.addWidget(self.scrape_output,1)
        row=QHBoxLayout(); row.addWidget(self.button('Save scraped page report',self.save_scraped)); row.addWidget(self.button('Export CSV',lambda:self.export_scraped('csv'))); row.addWidget(self.button('Export JSON',lambda:self.export_scraped('json'))); v.addLayout(row); return w
    def do_scrape(self):
        url=self.url_input.text().strip()
        if not url:return self.error('Enter a public webpage URL.')
        self.start_worker(lambda:PublicWebScraper().fetch(url),self.scrape_done)
    def scrape_done(self,page):
        self.latest_page=page; self.db.add_scraped_page(page); self.db.add_query(page['url'],'Web Scraping');
        self.scrape_output.setPlainText(f"Title: {page['title']}\nDescription: {page['description']}\nURL: {page['url']}\nRetrieved: {now_iso()}\n\nHeadings:\n"+'\n'.join('• '+h for h in page['headings'])+'\n\nExtracted text:\n'+page['text'])
        self.notice('Public webpage extracted and saved.'); self.refresh_home()
    def save_scraped(self):
        if not self.latest_page:return self.error('Scrape a page first.')
        p=self.latest_page; content=f"Title: {p['title']}\nDescription: {p['description']}\nURL: {p['url']}\nHeadings: {json.dumps(p['headings'],ensure_ascii=False)}\n\n{p['text']}"
        self.db.save_report(p['title'] or p['url'],'Web Scraping',p['url'],content,[p['url']]); self.notice('Report saved.'); self.refresh_home()
    def export_scraped(self,kind):
        if not self.latest_page:return self.error('Scrape a page first.')
        path,_=QFileDialog.getSaveFileName(self,'Export webpage',f'webpage.{kind}', 'CSV (*.csv)' if kind=='csv' else 'JSON (*.json)')
        if not path:return
        try: (export_csv(path,[self.latest_page]) if kind=='csv' else export_json(path,self.latest_page)); self.notice('Export complete.')
        except Exception as e:self.error(str(e))
    def ai_page(self):
        w,v=self.page('AI Analysis','AI reports are generated from evidence you provide or scrape. Configure an API provider in Settings first.')
        form=QFormLayout(); self.ai_topic=QLineEdit(); self.ai_topic.setPlaceholderText('Company, industry, or market'); self.ai_type=QComboBox(); self.ai_type.addItems(['SWOT Analysis','Key Insights','Market Opportunities','Recommendations','Executive Summary']); form.addRow('Research topic',self.ai_topic); form.addRow('Analysis type',self.ai_type); v.addLayout(form)
        tabs=QTabWidget(); self.ai_output=QTextEdit(); self.ai_output.setReadOnly(True); tabs.addTab(self.ai_output,'Analysis'); source=self.ai_sources=QTextEdit(); source.setPlaceholderText('Paste sourced research text and URLs here, or use saved scraped page evidence.'); tabs.addTab(source,'Evidence & Sources'); v.addWidget(tabs,1); v.addWidget(self.button('Generate Analysis',self.do_ai,True)); return w
    def do_ai(self):
        topic=self.ai_topic.text().strip(); evidence=self.ai_sources.toPlainText().strip()
        if not topic or not evidence:return self.error('Enter a topic and provide evidence with source URLs.')
        svc=AIService(self.db.setting('ai_api_key'),self.db.setting('ai_base_url','https://api.openai.com/v1'),self.db.setting('ai_model','gpt-4o-mini'))
        self.start_worker(lambda:svc.analyze(topic,evidence,self.ai_type.currentText()),lambda text:self.ai_done(topic,text,evidence))
    def ai_done(self,topic,text,evidence):
        self.ai_output.setPlainText(text); self.db.save_report(topic+' — '+self.ai_type.currentText(),'AI Analysis',topic,text,[line.strip() for line in evidence.splitlines() if line.strip().startswith('http')]);
        with self.db.connect() as con: con.execute('INSERT INTO ai_analyses(topic,analysis_type,content,sources,created_at) VALUES(?,?,?,?,?)',(topic,self.ai_type.currentText(),text,'[]',now_iso()))
        self.db.log('AI analysis completed',topic); self.notice('Analysis generated and saved.'); self.refresh_home()
    def reports_page(self):
        w,v=self.page('Saved Reports','Reports persist in the local SQLite database. Select a row to view, export, or delete it.')
        self.report_table=QTableWidget(0,5); self.report_table.setHorizontalHeaderLabels(['Name','Type','Subject','Created','Status']); self.report_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch); v.addWidget(self.report_table,1)
        row=QHBoxLayout(); row.addWidget(self.button('View report',self.view_report)); row.addWidget(self.button('Export JSON',lambda:self.export_report('json'))); row.addWidget(self.button('Export CSV',lambda:self.export_report('csv'))); row.addWidget(self.button('Delete report',self.delete_report)); v.addLayout(row); return w
    def refresh_reports(self):
        if not hasattr(self,'report_table'):return
        self.report_rows=self.db.rows('SELECT * FROM saved_reports ORDER BY id DESC'); self.report_table.setRowCount(len(self.report_rows))
        for i,row in enumerate(self.report_rows):
            for c,k in enumerate(('report_name','research_type','subject','created_at','status')):self.report_table.setItem(i,c,QTableWidgetItem(str(row[k])))
    def selected_report(self):
        i=self.report_table.currentRow()
        if i<0 or i>=len(getattr(self,'report_rows',[])): self.error('Select a report first.'); return None
        return self.report_rows[i]
    def view_report(self):
        r=self.selected_report()
        if r: QMessageBox.information(self,r['report_name'],r['content'][:12000])
    def export_report(self,kind):
        r=self.selected_report()
        if not r:return
        path,_=QFileDialog.getSaveFileName(self,'Export report',f'report.{kind}','JSON (*.json)' if kind=='json' else 'CSV (*.csv)')
        if not path:return
        try:(export_json(path,r) if kind=='json' else export_csv(path,[r]));self.notice('Export complete.')
        except Exception as e:self.error(str(e))
    def delete_report(self):
        r=self.selected_report()
        if not r:return
        if QMessageBox.question(self,'Confirm deletion',f"Delete '{r['report_name']}'?")==QMessageBox.StandardButton.Yes:
            with self.db.connect() as con:con.execute('DELETE FROM saved_reports WHERE id=?',(r['id'],))
            self.db.log('Report deleted',r['report_name']);self.refresh_reports();self.refresh_home()
    def settings_page(self):
        w,v=self.page('Settings','API keys are stored in the local settings database. For stronger protection, use OS keychain storage before distributing this app.')
        f,fl=self.card('Search provider','Brave Search API is used for live web search. Configure a key to enable search.'); v.addWidget(f)
        self.search_key=QLineEdit(self.db.setting('search_api_key')); self.search_key.setEchoMode(QLineEdit.EchoMode.Password); fl.addWidget(QLabel('Brave Search API key')); fl.addWidget(self.search_key)
        f2,fl2=self.card('AI provider','OpenAI-compatible Chat Completions endpoint. Provider costs and availability depend on your account.');v.addWidget(f2)
        self.ai_key=QLineEdit(self.db.setting('ai_api_key'));self.ai_key.setEchoMode(QLineEdit.EchoMode.Password);self.ai_base=QLineEdit(self.db.setting('ai_base_url','https://api.openai.com/v1'));self.ai_model=QLineEdit(self.db.setting('ai_model','gpt-4o-mini'))
        form=QFormLayout();form.addRow('API key',self.ai_key);form.addRow('Base URL',self.ai_base);form.addRow('Model',self.ai_model);fl2.addLayout(form)
        self.results_count=QSpinBox();self.results_count.setRange(1,20);self.results_count.setValue(int(self.db.setting('results_per_page','10')));fl2.addWidget(QLabel('Results per page'));fl2.addWidget(self.results_count)
        v.addWidget(self.button('Save Settings',self.save_settings,True));v.addStretch();return w
    def save_settings(self):
        for k,val in [('search_api_key',self.search_key.text().strip()),('ai_api_key',self.ai_key.text().strip()),('ai_base_url',self.ai_base.text().strip()),('ai_model',self.ai_model.text().strip()),('results_per_page',str(self.results_count.value()))]:self.db.set_setting(k,val)
        self.db.log('Settings updated','Provider settings saved');self.notice('Settings saved locally.');self.refresh_home()
    def start_worker(self,fn,on_success):
        if self.worker and self.worker.isRunning():return self.error('A task is already running. Please wait for it to finish.')
        self.status_label.setText('●  Working…\nPowered by Python & Qt')
        self.worker=Worker(fn);self.worker.succeeded.connect(lambda x:(on_success(x),self.status_label.setText('●  System Ready\nPowered by Python & Qt')));self.worker.failed.connect(lambda e:(self.status_label.setText('●  System Ready\nPowered by Python & Qt'),self.error(e)));self.worker.start()
    def notice(self,msg):QMessageBox.information(self,'Business Research AI',msg)
    def error(self,msg):QMessageBox.warning(self,'Business Research AI',msg)
