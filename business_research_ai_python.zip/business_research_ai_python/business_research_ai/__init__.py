"""Business Research AI desktop application."""
__version__ = "0.1.0"
