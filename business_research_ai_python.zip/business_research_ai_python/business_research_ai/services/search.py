"""Search adapter. Requires a configured Brave Search API key; never scrapes search pages."""
import httpx

class SearchService:
    ENDPOINT='https://api.search.brave.com/res/v1/web/search'
    def __init__(self, api_key=''): self.api_key=api_key.strip()
    def search(self, query, count=10):
        if not self.api_key: raise RuntimeError('Search is not configured. Add a Brave Search API key in Settings.')
        with httpx.Client(timeout=15) as client:
            r=client.get(self.ENDPOINT,params={'q':query,'count':max(1,min(int(count),20))},headers={'X-Subscription-Token':self.api_key,'Accept':'application/json'})
            r.raise_for_status(); payload=r.json()
        items=[]
        for x in payload.get('web',{}).get('results',[]):
            url=x.get('url','')
            if url and url not in {i['url'] for i in items}:
                items.append({'title':x.get('title',''), 'url':url, 'description':x.get('description',''), 'provider':'Brave Search'})
        return items
