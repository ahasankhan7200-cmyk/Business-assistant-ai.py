import csv, json
from pathlib import Path

def export_json(path, data):
    Path(path).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
def export_csv(path, rows):
    rows=list(rows)
    if not rows: raise ValueError('There is no data to export.')
    with open(path,'w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0].keys()),extrasaction='ignore'); writer.writeheader(); writer.writerows(rows)
