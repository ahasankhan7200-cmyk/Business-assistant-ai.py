from __future__ import annotations
import ipaddress, socket
from urllib.parse import urlparse, urljoin
import httpx
from bs4 import BeautifulSoup

MAX_BYTES = 3_000_000

def validate_public_url(url: str) -> str:
    p=urlparse(url.strip())
    if p.scheme not in ('http','https'): raise ValueError('Only http:// and https:// URLs are allowed.')
    if not p.hostname: raise ValueError('URL must include a hostname.')
    host=p.hostname.lower().rstrip('.')
    if host in ('localhost',) or host.endswith('.localhost') or host.endswith('.local'):
        raise ValueError('Local and private-network destinations are blocked.')
    try:
        addresses=socket.getaddrinfo(host, p.port or (443 if p.scheme=='https' else 80), type=socket.SOCK_STREAM)
        for item in addresses:
            ip=ipaddress.ip_address(item[4][0])
            if not ip.is_global: raise ValueError('Local and private-network destinations are blocked.')
    except socket.gaierror as e:
        raise ValueError(f'Could not resolve hostname: {host}') from e
    return url

def extract_html(url: str, html: str) -> dict:
    soup=BeautifulSoup(html,'html.parser')
    for tag in soup(['script','style','noscript','svg','nav','footer']): tag.decompose()
    title=soup.title.get_text(' ',strip=True) if soup.title else ''
    meta=soup.find('meta',attrs={'name':'description'}) or soup.find('meta',attrs={'property':'og:description'})
    description=meta.get('content','').strip() if meta else ''
    headings=[h.get_text(' ',strip=True) for h in soup.find_all(['h1','h2','h3']) if h.get_text(strip=True)]
    text='\n'.join(x.strip() for x in soup.stripped_strings)
    return {'url':url,'title':title,'description':description,'headings':headings,'text':text[:100000],'status':'Completed'}

class PublicWebScraper:
    def fetch(self, url: str) -> dict:
        validate_public_url(url)
        headers={'User-Agent':'BusinessResearchAI/0.1 (public research; contact: administrator)'}
        # Redirects are checked one hop at a time to prevent redirect-based SSRF.
        with httpx.Client(timeout=httpx.Timeout(15), follow_redirects=False, headers=headers) as client:
            current=url
            for _ in range(6):
                validate_public_url(current)
                with client.stream('GET',current) as response:
                    if response.status_code in (301,302,303,307,308):
                        location=response.headers.get('location')
                        if not location: raise RuntimeError('Redirect response did not include a destination.')
                        current=urljoin(current,location); continue
                    response.raise_for_status()
                    ctype=response.headers.get('content-type','').lower()
                    if 'text/html' not in ctype and 'application/xhtml+xml' not in ctype:
                        raise RuntimeError(f'Unsupported content type: {ctype or "unknown"}; expected HTML.')
                    chunks=[]; total=0
                    for chunk in response.iter_bytes():
                        total += len(chunk)
                        if total>MAX_BYTES: raise RuntimeError('Page exceeds the 3 MB response limit.')
                        chunks.append(chunk)
                    html=b''.join(chunks).decode(response.encoding or 'utf-8',errors='replace')
                    return extract_html(str(response.url),html)
            raise RuntimeError('Too many redirects.')
