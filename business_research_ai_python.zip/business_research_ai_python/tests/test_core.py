import json
import pytest
from business_research_ai.database import Database
from business_research_ai.services.scraper import extract_html, validate_public_url
from business_research_ai.services.exporter import export_json, export_csv
from business_research_ai.services.analysis import AIService

def test_database_report_persists(tmp_path):
    db=Database(tmp_path/'test.sqlite3')
    rid=db.save_report('Demo','Test','topic','report body',['https://example.com'])
    assert rid > 0
    assert db.rows('SELECT report_name,content FROM saved_reports')[0]['content']=='report body'

def test_html_extraction():
    result=extract_html('https://example.com','<html><head><title>Demo</title><meta name="description" content="desc"></head><body><h1>Heading</h1><script>secret</script><p>Hello</p></body></html>')
    assert result['title']=='Demo' and result['description']=='desc'
    assert result['headings']==['Heading'] and 'Hello' in result['text'] and 'secret' not in result['text']

def test_url_scheme_validation():
    with pytest.raises(ValueError): validate_public_url('file:///etc/passwd')
    with pytest.raises(ValueError): validate_public_url('http://localhost')

def test_exports(tmp_path):
    j=tmp_path/'out.json'; c=tmp_path/'out.csv'
    export_json(j,{'name':'Demo'}); export_csv(c,[{'name':'Demo','url':'https://example.com'}])
    assert json.loads(j.read_text())['name']=='Demo'
    assert 'name,url' in c.read_text(encoding='utf-8-sig')

def test_ai_missing_key():
    with pytest.raises(RuntimeError,match='requires an API key'):
        AIService().analyze('topic','evidence')
