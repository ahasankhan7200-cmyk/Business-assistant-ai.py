# Business Research AI — Python Desktop Edition

A desktop research application built with **Python 3.11+ and PySide6**, SQLite, HTTPX and BeautifulSoup. This Python edition is a separate implementation of the requested Business Research AI workflow; it is not a conversion of C++ syntax line-by-line.

## Implemented
- PySide6 desktop GUI with dark navigation sidebar and Home, Business Research, Competitor Analysis, Web Scraping, AI Analysis, Saved Reports, and Settings screens.
- SQLite persistence for companies, queries, search results, scraped pages, competitors, comparisons, market research, AI analyses, saved reports, settings and activity logs.
- Optional live web search using the documented Brave Search API (`X-Subscription-Token`). Requires an API key.
- Public HTML page retrieval and extraction with timeouts, response-size cap, redirect checks, and blocking for local/private IP destinations.
- AI analysis using an OpenAI-compatible Chat Completions API. Requires an API key and may incur provider charges.
- Saved reports and JSON/CSV exports.
- Basic automated tests for database persistence, HTML extraction, URL restrictions, exports, and missing AI credentials.

## Limitations
- Competitor analysis currently discovers sourced web results; it does not automatically verify every competitor's pricing, features, strengths or weaknesses. Those claims must be researched from cited pages before treating them as facts.
- No PDF or native Excel export is included in this version.
- API keys are masked in the UI but stored in the local SQLite settings table. This is not equivalent to OS keychain encryption; do not distribute the app to untrusted machines without implementing a keychain-backed credential store.
- SSRF protections include DNS/IP validation and redirect revalidation, but DNS rebinding can require stronger network-level controls in a production deployment. Robots.txt and each site's terms must be checked before scraping; this starter does not yet implement automatic robots.txt evaluation. Use only pages you are permitted to access.
- The application is not a market-data terminal and does not promise exhaustive search coverage.

## Install on Windows
1. Install Python 3.11 or newer from https://www.python.org/downloads/ and enable the option to add Python to PATH.
2. Open PowerShell in this folder.
3. Create a virtual environment:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```
4. Run the app:
   ```powershell
   python -m business_research_ai.main
   ```
5. Run tests:
   ```powershell
   pip install pytest
   pytest -q
   ```

## Install on Ubuntu / Debian
```bash
sudo apt update
sudo apt install python3 python3-venv python3-pip
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m business_research_ai.main
```

For headless environments, Qt GUI launch requires a desktop display server. Tests can run without starting the GUI.

## Configure services
Open **Settings** inside the app.
- **Search:** obtain a Brave Search API key from https://brave.com/search/api/ and paste it in the search key field.
- **AI:** enter an API key, compatible base URL (default `https://api.openai.com/v1`), and model name. A provider may charge for API usage.

Never commit real API keys to Git. For production, replace local SQLite key storage with Windows Credential Manager, macOS Keychain, or Linux Secret Service.

## Data location
The database is stored at `~/.business_research_ai/research.sqlite3` (on Windows this is under the user's home directory). Back it up while the application is closed.

## Project layout
```text
business_research_ai_python/
├── business_research_ai/
│   ├── main.py
│   ├── database.py
│   ├── ui/main_window.py
│   └── services/{scraper,search,analysis,exporter}.py
├── tests/test_core.py
├── requirements.txt
└── README.md
```

## Feature checklist
| Requirement | Status |
|---|---|
| Desktop dashboard/navigation | Implemented |
| SQLite persistence and activity history | Implemented |
| Public HTML extraction | Implemented, robots.txt enforcement still needed |
| Live company/market search | Implemented with configured Brave API |
| Competitor discovery | Partial; sourced search results, not fully normalized competitor profiles |
| Market research engine with verified market metrics | Partial; no specialized market-data provider |
| AI SWOT/insights/recommendations | Implemented through configured compatible API; evidence must be supplied |
| Saved reports | Implemented |
| CSV/JSON export | Implemented |
| PDF/Excel export | Not implemented |
| OS keychain API-key storage | Not implemented |
| Automated tests | Written; execution status depends on installed dependencies |

## Test commands
```bash
python -m compileall business_research_ai
pytest -q
```
Do not treat tests as passed until they have actually been run in the target environment.
